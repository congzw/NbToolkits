#版本文件夹结构说明

##项目结构简介

todo

##详细说明
- **build** 包含构建脚本和一些支持性文件(e.g., PowerShell scripts, EXEs, and the parameters file, etc.)
- **doc** 包含构文档(e.g., developer documents, installation guides, tips, requirements, etc.) 
- **src** 源代码(e.g.,  Visual Studio solution, all project folders, etc.)