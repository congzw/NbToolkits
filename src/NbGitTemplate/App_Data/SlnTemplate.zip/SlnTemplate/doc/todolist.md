# TODOLIST

## How To Use

	- [] for an empty checkbox
	- [x] for a checked checkbox

## setup dev structure

- [x] create empty sln folder(with .gitattributes and .gitignore files)
- [x] Git Bash Here: [git init]		
- [x] open sln and add doc(readme.md,  todolist.md), first commit!
- [x] add basic projects
- [x] add test projects and ref
- [x] commit!

## Jobs